// Mock authentication system for demo purposes
export interface User {
  id: string
  name: string
  email: string
  platform: "spotify" | "apple"
  avatar?: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}

// Mock user data
const mockUsers = {
  spotify: {
    id: "spotify_user_123",
    name: "John Doe",
    email: "john@example.com",
    platform: "spotify" as const,
    avatar: "/diverse-user-avatars.png",
  },
  apple: {
    id: "apple_user_456",
    name: "Jane Smith",
    email: "jane@example.com",
    platform: "apple" as const,
    avatar: "/diverse-user-avatars.png",
  },
}

// Simulate OAuth login process
export const loginWithPlatform = async (platform: "spotify" | "apple"): Promise<User> => {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // Simulate successful authentication
  const user = mockUsers[platform]
  localStorage.setItem("auth_user", JSON.stringify(user))
  return user
}

export const logout = (): void => {
  localStorage.removeItem("auth_user")
}

export const getCurrentUser = (): User | null => {
  if (typeof window === "undefined") return null

  const stored = localStorage.getItem("auth_user")
  if (!stored) return null

  try {
    return JSON.parse(stored)
  } catch {
    return null
  }
}

export const isAuthenticated = (): boolean => {
  return getCurrentUser() !== null
}
